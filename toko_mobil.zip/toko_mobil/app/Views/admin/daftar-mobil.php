<?= $this->extend('admin/template'); ?>
<?= $this->section('main'); ?>
<h2 class="mb-5 fw-bold text-primary">
    <i class="fas fa-car me-2"></i> Daftar Mobil
</h2>
<div class="d-flex justify-content-between align-items-center mb-4">
    <a href="<?= base_url('admin/daftar-mobil/tambah') ?>" class="btn btn-primary btn-lg">
        <i class="fas fa-plus me-1"></i> Tambah Mobil
    </a>
</div>
<div class="card shadow-sm border-0 rounded-4">
    <div class="card-body">
        <table class="table table-hover align-middle">
            <thead class="table-light">
                <tr>
                    <th scope="col" class="text-center">No</th>
                    <th scope="col">Nama</th>
                    <th scope="col">Kategori</th>
                    <th scope="col">Deskripsi</th>
                    <th scope="col" class="text-center">Stok</th>
                    <th scope="col" class="text-center">Gambar</th>
                    <th scope="col" class="text-center">Harga</th>
                    <th scope="col" class="text-center">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($mobils as $key => $mobil): ?>
                <tr>
                    <th scope="row" class="text-center"><?= $key + 1 ?></th>
                    <td><?= $mobil['nama'] ?></td>
                    <td><?= $mobil['kategori'] ?></td>
                    <td><?= $mobil['deskripsi'] ?></td>
                    <td class="text-center"><?= $mobil['stok'] ?></td>
                    <td class="text-center">
                        <img src="<?= base_url($mobil['gambar']) ?>" alt="<?= $mobil['nama'] ?>" class="img-thumbnail" style="width: 100px; height: auto;">
                    </td>
                    <td class="text-center">Rp<?= number_format($mobil['harga'], 0, ',', '.') ?></td>
                    <td class="text-center">
                        <a href="<?= base_url('admin/daftar-mobil/edit') ?>/<?= $mobil['id'] ?>" class="btn btn-success btn-sm">
                            <i class="fas fa-edit me-1"></i> Edit
                        </a>
                        <a href="<?= base_url('admin/daftar-mobil/hapus') ?>/<?= $mobil['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Apakah Anda yakin ingin menghapus item ini?')">
                            <i class="fas fa-trash me-1"></i> Hapus
                        </a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<?= $this->endSection(); ?>
