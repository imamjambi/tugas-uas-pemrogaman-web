<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Home::index');
$routes->get('/chart', 'Home::chart');
$routes->get('/checkout', 'Home::checkout');

$routes->post('/submit', 'Home::submit');

$routes->get('images/(:segment)', 'Home::image/$1');

$routes->group('admin', ['filter' => ['group:admin']], function ($routes) {
    $routes->get('', 'AdminController::index');
    $routes->get('dashboard', 'AdminController::index');

    // Routes for "mobil" management
    $routes->get('daftar-mobil', 'AdminController::daftarMobil');
    $routes->get('daftar-mobil/tambah', 'AdminController::daftarMobilTambah');
    $routes->post('daftar-mobil/tambah', 'AdminController::createMobil');
    $routes->get('daftar-mobil/edit/(:num)', 'AdminController::daftarMobilEdit/$1');
    $routes->get('daftar-mobil/hapus/(:num)', 'AdminController::hapusMobil/$1');

    // Transactions
    $routes->get('transaksi', 'AdminController::transaksi');
    $routes->get('transaksi/ubah-status', 'AdminController::transaksiUbahStatus');
    $routes->get('transaksi/hapus', 'AdminController::transaksiHapus');

    // Customers
    $routes->get('pelanggan', 'AdminController::pelanggan');
    $routes->get('pelanggan/hapus', 'AdminController::pelangganHapus');
});

service('auth')->routes($routes);
