<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreateMobilsTable extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'id' => [
                'type' => 'INT',
                'constraint' => 11,
                'auto_increment' => true,
            ],
            'nama' => [ // Nama mobil
                'type' => 'VARCHAR',
                'constraint' => 225,
            ],
            'merk' => [ // Merek mobil (Toyota, Honda, dll.)
                'type' => 'VARCHAR',
                'constraint' => 225,
            ],
            'model' => [ // Model mobil (Avanza, Civic, dll.)
                'type' => 'VARCHAR',
                'constraint' => 225,
            ],
            'tahun' => [ // Tahun produksi mobil
                'type' => 'YEAR',
            ],
            'warna' => [ // Warna mobil
                'type' => 'VARCHAR',
                'constraint' => 100,
            ],
            'stok' => [ // Stok mobil
                'type' => 'INT',
                'constraint' => 11,
            ],
            'harga' => [ // Harga mobil
                'type' => 'INT',
                'constraint' => 16,
            ]
        ]);

        $this->forge->addKey('id', true);
        $this->forge->createTable('mobils');
    }

    public function down()
    {
        $this->forge->dropTable('mobils');
    }
}
