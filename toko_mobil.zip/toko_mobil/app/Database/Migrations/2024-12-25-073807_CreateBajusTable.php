<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreateBajusTable extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'id' => [
                'type' => 'INT',
                'constraint' => 11,
                'auto_increment' => true,
            ],
            'nama' => [
                'type' => 'VARCHAR',
                'constraint' => 225,
            ],
            'kategori' => [ // Misalnya kategori pakaian (kaos, kemeja, dll.)
                'type' => 'VARCHAR',
                'constraint' => 225,
            ],
            'bahan' => [
                'type' => 'VARCHAR',
                'constraint' => 225,
            ],
            'ukuran' => [ // Ukuran pakaian (S, M, L, XL)
                'type' => 'VARCHAR',
                'constraint' => 10,
            ],
            'warna' => [ // Warna pakaian
                'type' => 'VARCHAR',
                'constraint' => 100,
            ],
            'stok' => [ // Stok barang
                'type' => 'INT',
                'constraint' => 11,
            ],
            'harga' => [
                'type' => 'INT',
                'constraint' => 16,
            ]
        ]);

        $this->forge->addKey('id', true);
        $this->forge->createTable('bajus');
    }

    public function down()
    {
        $this->forge->dropTable('bajus');
    }
}
